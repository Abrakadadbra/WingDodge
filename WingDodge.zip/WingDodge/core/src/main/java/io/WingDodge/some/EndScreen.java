package io.WingDodge.some;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class EndScreen implements Screen {
    private final PlaneGame game;
    private Stage stage;
    private int score;

    // Текстуры
    private Texture retryTexture;
    private Texture retryPressedTexture;
    private Texture menuTexture;
    private Texture menuPressedTexture;

    public EndScreen(PlaneGame game, int score) {
        this.game = game;
        this.score = score;
    }

    @Override
    public void show() {
        // Загрузка текстур
        retryTexture = new Texture("retryButton.png");
        retryPressedTexture = new Texture("retryPressedButton.png");
        menuTexture = new Texture("menuButton.png");
        menuPressedTexture = new Texture("menuPressedButton.png");


        // Настройка UI
        setupUI();
        Gdx.input.setInputProcessor(stage);
    }

    private void setupUI() {
        stage = new Stage(new FitViewport(800, 480));
        Table table = new Table();
        table.setFillParent(true);

        // Создание стилей кнопок
        ImageButton.ImageButtonStyle retryButtonStyle = new ImageButton.ImageButtonStyle();
        retryButtonStyle.up = new TextureRegionDrawable(new TextureRegion(retryTexture));
        retryButtonStyle.down = new TextureRegionDrawable(new TextureRegion(retryPressedTexture));

        ImageButton.ImageButtonStyle menuButtonStyle = new ImageButton.ImageButtonStyle();
        menuButtonStyle.up = new TextureRegionDrawable(new TextureRegion(menuTexture));
        menuButtonStyle.down = new TextureRegionDrawable(new TextureRegion(menuPressedTexture));

        // Создание кнопок
        ImageButton retryButton = new ImageButton(retryButtonStyle);
        ImageButton menuButton = new ImageButton(menuButtonStyle);

        // Создание текста счета
        Label.LabelStyle scoreStyle = new Label.LabelStyle();
        scoreStyle.font = new BitmapFont();
        scoreStyle.fontColor = Color.WHITE;
        Label scoreLabel = new Label("Score: " + score, scoreStyle);

        // Обработчики событий
        retryButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new GameScreen(game));
            }
        });

        menuButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuScreen(game));
            }
        });

        // Компоновка элементов
        table.defaults().pad(15);
        table.add(scoreLabel).padBottom(40).row();
        table.add(retryButton).width(retryTexture.getWidth()).height(retryTexture.getHeight()).padBottom(20).row();
        table.add(menuButton).width(menuTexture.getWidth()).height(menuTexture.getHeight());

        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.2f, 0.1f, 0.1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
        retryTexture.dispose();
        menuTexture.dispose();
    }

    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}
