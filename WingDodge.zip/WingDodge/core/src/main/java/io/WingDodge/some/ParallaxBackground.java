package io.WingDodge.some;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;

public class ParallaxBackground {
    private final Array<CelestialBody> celestialBodies = new Array<>();
    private final Texture starTexture;
    private int screenWidth;
    private int screenHeight;
    private final int layersCount;
    private final Vector2 playerVelocity = new Vector2();

    public ParallaxBackground(Texture starTexture, int screenWidth, int screenHeight,
                              int layersCount, int starsPerLayer) {
        this.starTexture = starTexture;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.layersCount = layersCount;

        createStars(starsPerLayer);
    }

    private void createStars(int starsPerLayer) {
        celestialBodies.clear();
        for (int layer = 0; layer < layersCount; layer++) {
            for (int i = 0; i < starsPerLayer; i++) {
                celestialBodies.add(new Star(layer));
            }

            if (layer > layersCount / 2) {
                for (int i = 0; i < 2; i++) {
                    celestialBodies.add(new Nebula(layer, i));
                }
            }
        }
    }

    public void update(float delta, Vector2 playerVelocity) {
        this.playerVelocity.set(playerVelocity);

        // Двигаем фон только если игрок движется
        if (!playerVelocity.isZero(0.1f)) {
            for (CelestialBody body : celestialBodies) {
                body.update(delta);
            }
        }
    }

    public void render(SpriteBatch batch) {
        for (CelestialBody body : celestialBodies) {
            body.render(batch);
        }
        batch.setColor(1, 1, 1, 1);
    }

    public void resize(int width, int height) {
        float[] relativePositions = new float[celestialBodies.size * 2];
        for (int i = 0; i < celestialBodies.size; i++) {
            CelestialBody body = celestialBodies.get(i);
            relativePositions[i * 2] = body.position.x / screenWidth;
            relativePositions[i * 2 + 1] = body.position.y / screenHeight;
        }

        screenWidth = width;
        screenHeight = height;

        for (int i = 0; i < celestialBodies.size; i++) {
            CelestialBody body = celestialBodies.get(i);
            body.position.x = relativePositions[i * 2] * screenWidth;
            body.position.y = relativePositions[i * 2 + 1] * screenHeight;
        }
    }

    public void dispose() {
        starTexture.dispose();
    }

    private abstract class CelestialBody {
        protected final Vector2 position;
        protected final float speed;
        protected float size;
        protected final float alpha;
        protected final int layer;
        protected final float depthFactor;

        public CelestialBody(int layer) {
            this.layer = layer;
            this.depthFactor = 1f - (float) layer / layersCount;
            this.speed = 50f + 150f * depthFactor;
            this.alpha = 0.3f + 0.7f * depthFactor;

            this.position = new Vector2(
                MathUtils.random(ParallaxBackground.this.screenWidth),
                MathUtils.random(ParallaxBackground.this.screenHeight)
            );
        }

        public void update(float delta) {
            // Автоматическое движение вниз ТОЛЬКО при движении игрока
            if (!playerVelocity.isZero(0.1f)) {
                position.y -= speed * delta * depthFactor;
            }

        }
        abstract void render (SpriteBatch batch);
    }

    private class Star extends CelestialBody {
        private final Color color;
        private final boolean twinkles;
        private float twinkleTimer;
        private float currentAlpha;
        private final boolean isSpecial;

        public Star(int layer) {
            super(layer);

            this.size = MathUtils.random(1.5f, 4f) + 4f * depthFactor;

            float colorVal = MathUtils.random(0.7f, 1f);
            if (MathUtils.random() < 0.2f) {
                color = new Color(colorVal, MathUtils.random(0.6f, 0.8f), MathUtils.random(0.7f, 1f), 1);
            } else if (MathUtils.random() < 0.1f) {
                color = new Color(MathUtils.random(0.9f, 1f), MathUtils.random(0.7f, 0.8f), MathUtils.random(0.5f, 0.6f), 1);
            } else {
                color = new Color(colorVal, colorVal, colorVal, 1);
            }

            this.isSpecial = MathUtils.random() < 0.05f;
            if (isSpecial) {
                size *= 3f;
            }

            this.twinkles = MathUtils.random() < 0.3f;
            this.twinkleTimer = MathUtils.random(0f, 10f);
            this.currentAlpha = alpha;
        }

        @Override
        public void update(float delta) {
            // Движение относительно игрока ТОЛЬКО при движении игрока
            if (!playerVelocity.isZero(0.1f)) {
                position.x -= playerVelocity.x * depthFactor * delta * 0.5f;
                position.y -= playerVelocity.y * depthFactor * delta * 0.5f;

                // Автоматическое движение вниз
                super.update(delta);

                // Проверка выхода за границы экрана
                if (position.y < -size * 2) {
                    position.y = ParallaxBackground.this.screenHeight + size;
                    position.x = MathUtils.random(ParallaxBackground.this.screenWidth);
                }
                if (position.x < -size * 2) {
                    position.x = ParallaxBackground.this.screenWidth + size;
                }
                if (position.x > screenWidth + size * 2) {
                    position.x = -size;
                }

                if (twinkles) {
                    twinkleTimer += delta * 2;
                    currentAlpha = alpha * (0.7f + 0.3f * MathUtils.sin(twinkleTimer));
                } else {
                    currentAlpha = alpha;
                }
            }
        }

        @Override
        public void render(SpriteBatch batch) {
            Color original = batch.getColor();

            if (isSpecial) {
                batch.setColor(1, 0.9f, 0.8f, currentAlpha * 1.2f);
                batch.draw(
                    starTexture,
                    position.x - size/2,
                    position.y - size/2,
                    size,
                    size
                );
            } else {
                batch.setColor(color.r, color.g, color.b, currentAlpha);
                batch.draw(
                    starTexture,
                    position.x - size/2,
                    position.y - size/2,
                    size,
                    size
                );
            }

            batch.setColor(original);
        }
    }

    private class Nebula extends CelestialBody {
        private final float width;
        private final float height;
        private final Color tint;

        public Nebula(int layer, int seed) {
            super(layer);
            this.size = MathUtils.random(1f, 3f);
            this.width = MathUtils.random(100f, 300f) * (1 + layer/2f);
            this.height = MathUtils.random(20f, 40f);

            float hue = MathUtils.random();
            if (hue < 0.3f) {
                tint = new Color(0.6f, 0.5f, 0.8f, 1);
            } else if (hue < 0.6f) {
                tint = new Color(0.4f, 0.6f, 0.8f, 1);
            } else {
                tint = new Color(0.8f, 0.4f, 0.5f, 1);
            }
            tint.a = alpha * 0.15f;
        }

        @Override
        public void update(float delta) {
            // Движение ТОЛЬКО при движении игрока
            if (!playerVelocity.isZero(0.1f)) {
                position.x -= playerVelocity.x * depthFactor * delta * 0.2f;
                position.y -= playerVelocity.y * depthFactor * delta * 0.2f;

                // Автоматическое движение вниз
                position.y -= speed * 0.3f * delta * depthFactor;

                if (position.y < -height * 2) {
                    position.y = ParallaxBackground.this.screenHeight + height;
                    position.x = MathUtils.random(ParallaxBackground.this.screenWidth);
                }
            }
        }

        @Override
        public void render(SpriteBatch batch) {
            Color original = batch.getColor();
            batch.setColor(tint);

            for (int i = 0; i < 15; i++) {
                float offsetX = MathUtils.random(-width/2, width/2);
                float offsetY = MathUtils.random(-height/2, height/2);
                float starSize = size * MathUtils.random(0.8f, 1.2f);

                batch.draw(
                    starTexture,
                    position.x + offsetX - starSize/2,
                    position.y + offsetY - starSize/2,
                    starSize,
                    starSize
                );
            }

            batch.setColor(original);
        }
    }
}
