package io.WingDodge.some;

import com.badlogic.gdx.Game;

public class PlaneGame extends Game {
    public enum Difficulty {
        EASY, MEDIUM, HARD
    }
    @Override
    public void create() {
        setScreen(new MainMenuScreen(this));
    }
}
