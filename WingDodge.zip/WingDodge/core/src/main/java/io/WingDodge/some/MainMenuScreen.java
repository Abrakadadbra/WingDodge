package io.WingDodge.some;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class MainMenuScreen implements Screen {
    private final PlaneGame game;
    private Stage stage;

    public MainMenuScreen(PlaneGame game) {
        this.game = game;
        setupUI();
    }

    private void setupUI() {
        stage = new Stage(new FitViewport(800, 480));
        Gdx.input.setInputProcessor(stage);

        Table table = new Table();
        table.setFillParent(true);

        // Загрузка текстур для кнопок
        Texture playTexture = new Texture("playButton.png");
        Texture playPressedTexture = new Texture("playButtonPressed.png");
        Texture exitTexture = new Texture("exitButton.png");
        Texture exitPressedTexture = new Texture("exitButtonPressed.png");
//        Texture backgroundTexture = new Texture("menuBackground.png");


        // Создание стиля для кнопок
        ImageButton.ImageButtonStyle playButtonStyle = new ImageButton.ImageButtonStyle();
        playButtonStyle.up = new TextureRegionDrawable(new TextureRegion(playTexture));
        playButtonStyle.down = new TextureRegionDrawable(new TextureRegion(playPressedTexture));

        ImageButton.ImageButtonStyle exitButtonStyle = new ImageButton.ImageButtonStyle();
        exitButtonStyle.up = new TextureRegionDrawable(new TextureRegion(exitTexture));
        exitButtonStyle.down = new TextureRegionDrawable(new TextureRegion(exitPressedTexture));

        // Создание кнопок
        ImageButton playButton = new ImageButton(playButtonStyle);
        ImageButton exitButton = new ImageButton(exitButtonStyle);

        // Создание изображений
//        Image background = new Image(backgroundTexture);


        // Настройка обработчиков событий
        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new GameScreen(game));
            }
        });

        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });

        // Компоновка элементов
//        table.setBackground(new TextureRegionDrawable(new TextureRegion(backgroundTexture)));
        table.defaults().pad(15);


        table.add(playButton).width(playTexture.getWidth()).height(playTexture.getHeight()).padTop(50).row();
        table.add(exitButton).width(exitTexture.getWidth()).height(exitTexture.getHeight()).padTop(20).row();

        stage.addActor(table);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.1f, 0.1f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(Math.min(delta, 1/30f));
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        if (stage != null) {
            stage.dispose();
        }
    }

    @Override public void show() {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}
