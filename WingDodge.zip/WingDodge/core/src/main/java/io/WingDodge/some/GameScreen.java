package io.WingDodge.some;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.util.Iterator;


public class GameScreen implements Screen {

    private OrthographicCamera camera;
    private SpriteBatch batch;
    private Player player;
    private ObstacleManager obstacles;
    private Stage stage;
    private Label scoreLabel;
    public int score = 0;
    private float gameTime = 0;
    private boolean obstacleSpawned;
    private ShapeRenderer shapeRenderer;
    private ParallaxBackground background;

    private boolean isTouching = false; // Флаг касания экрана

    private Texture playerTexture;
    private Texture[] obstacleTextures;
    private Texture explosionTexture; // Текстура взрыва
    private Texture extraHeartTexture; // Текстура для сердечка-бонуса
    private Texture extraShieldTexture; // Текстура падающего щита
    private Texture activeShieldTexture; // Текстура активного щита в UI
    private Texture extraBulletTexture; // Текстура выпадающей пули-бонуса
    private Texture bulletEffectTexture; // Текстура иконки эффекта пули

    private static Vector2 targetPosition = new Vector2((Gdx.graphics.getWidth() / 2), (Gdx.graphics.getHeight() / 2));
    private static boolean DEBUG_MODE = false;

    private int lives = 3;
    private Texture heartTexture;

    private boolean isInvincible = false;
    private float invincibleTimer = 0;
    private static final float INVINCIBLE_DURATION = 2.0f;

    // Состояние щита
    private boolean isShieldActive = false;
    private float shieldTimer = 0;
    private static final float SHIELD_DURATION = 10.0f;

    // Эффект улучшения пуль
    private boolean isBulletEffectActive = false;
    private float bulletEffectTimer = 0;
    private static final float BULLET_EFFECT_DURATION = 10.0f;

    // Список активных сердечек-бонусов
    private Array<Heart> hearts;
    // Список активных щитов
    private Array<Shield> shields;
    // Список активных пуль-бонусов
    private Array<ExtraBullet> extraBullets;

    private final PlaneGame game;

    // Система стрельбы
    private Array<Bullet> bullets;
    private Array<Explosion> explosions; // Список активных взрывов

    public GameScreen(PlaneGame game) {
        this.game = game;
    }

    @Override
    public void show() {
        shapeRenderer = new ShapeRenderer();
        camera = new OrthographicCamera();
        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        batch = new SpriteBatch();

        playerTexture = new Texture("plane.png");
        obstacleTextures = new Texture[]{
            new Texture("ufo.png"),
            new Texture("ufo1.png")
        };
        explosionTexture = new Texture("explosion.png"); // Загрузка текстуры взрыва
        extraHeartTexture = new Texture("extraHeart.png"); // Загрузка текстуры сердечка
        extraShieldTexture = new Texture("extraShield.png"); // Загрузка текстуры щита
        activeShieldTexture = new Texture("shield.png"); // Загрузка текстуры активного щита
        extraBulletTexture = new Texture("extraBullet.png"); // Загрузка текстуры пули-бонуса
        bulletEffectTexture = new Texture("bullet.png"); // Загрузка текстуры иконки эффекта

        Texture starTexture = new Texture("star.png");

        heartTexture = new Texture("heart.png");

        background = new ParallaxBackground(
            starTexture,
            Gdx.graphics.getWidth(),
            Gdx.graphics.getHeight(),
            4,
            50
        );

        float startX = Gdx.graphics.getWidth() / 2f - playerTexture.getWidth() / 2f;
        float startY = Gdx.graphics.getHeight() / 2f - playerTexture.getHeight() / 2f;

        player = new Player(playerTexture, startX, startY);
        player.setPosition(startX, startY);

        obstacles = new ObstacleManager(obstacleTextures);

        bullets = new Array<>(); // Инициализация пуль
        explosions = new Array<>(); // Инициализация взрывов
        hearts = new Array<>(); // Инициализация сердечек
        shields = new Array<>(); // Инициализация щитов
        extraBullets = new Array<>(); // Инициализация пуль-бонусов

        setupUI();
        setupInput();
    }

    private void setupUI() {
        stage = new Stage(new ScreenViewport());

        Label.LabelStyle style = new Label.LabelStyle();
        style.font = new BitmapFont();
        style.fontColor = Color.WHITE;

        scoreLabel = new Label("Score: 0", style);
        scoreLabel.setPosition(20, Gdx.graphics.getHeight() - 40);
        stage.addActor(scoreLabel);
    }

    private void setupInput() {
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                isTouching = true; // Устанавливаем флаг при касании
                Vector3 touchPos = new Vector3(screenX, screenY, 0);
                camera.unproject(touchPos);
                player.setTargetPosition(touchPos.x, touchPos.y);
                return true;
            }

            @Override
            public boolean touchUp(int screenX, int screenY, int pointer, int button) {
                isTouching = false; // Сбрасываем флаг при отпускании
                return true;
            }

            @Override
            public boolean touchDragged(int screenX, int screenY, int pointer) {
                Vector3 touchPos = new Vector3(screenX, screenY, 0);
                camera.unproject(touchPos);
                player.setTargetPosition(touchPos.x, touchPos.y);
                return true;
            }
        });
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.02f, 0.02f, 0.05f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        update(delta);

        if (Gdx.input.isKeyJustPressed(Input.Keys.F1)) {
            DEBUG_MODE = !DEBUG_MODE;
        }

        // Отрисовка фона
        batch.begin();
        background.render(batch);
        batch.end();

        // Отрисовка игровых объектов
        batch.setProjectionMatrix(camera.combined);
        shapeRenderer.setProjectionMatrix(camera.combined);

        batch.begin();
        player.render(batch);
        obstacles.render(batch);

        // Отрисовка сердечек-бонусов
        for (Heart heart : hearts) {
            heart.render(batch);
        }

        // Отрисовка щитов-бонусов
        for (Shield shield : shields) {
            shield.render(batch);
        }

        // Отрисовка пуль-бонусов
        for (ExtraBullet bullet : extraBullets) {
            bullet.render(batch);
        }

        // Отрисовка взрывов
        for (Explosion explosion : explosions) {
            explosion.render(batch);
        }
        batch.end();

        // Отрисовка пуль
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        for (Bullet bullet : bullets) {
            shapeRenderer.setColor(bullet.isPlayerBullet() ? Color.YELLOW : Color.RED);
            bullet.render(shapeRenderer);
        }
        shapeRenderer.end();

        // Отладочная отрисовка границ
        if (DEBUG_MODE) {
            shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
            shapeRenderer.setColor(Color.RED);
            shapeRenderer.rect(player.getBounds().x, player.getBounds().y,
                player.getBounds().width, player.getBounds().height);

            // Отрисовка орудий и направления
            player.renderDebug(shapeRenderer);

            for (Obstacle obstacle : obstacles.getObstacles()) {
                shapeRenderer.rect(obstacle.getBounds().x, obstacle.getBounds().y,
                    obstacle.getBounds().width, obstacle.getBounds().height);
            }

            // Отрисовка сердечек (для отладки)
            for (Heart heart : hearts) {
                shapeRenderer.rect(heart.getBounds().x, heart.getBounds().y,
                    heart.getBounds().width, heart.getBounds().height);
            }

            // Отрисовка щитов (для отладки)
            for (Shield shield : shields) {
                shapeRenderer.rect(shield.getBounds().x, shield.getBounds().y,
                    shield.getBounds().width, shield.getBounds().height);
            }

            // Отрисовка пуль-бонусов (для отладки)
            for (ExtraBullet bullet : extraBullets) {
                shapeRenderer.rect(bullet.getBounds().x, bullet.getBounds().y,
                    bullet.getBounds().width, bullet.getBounds().height);
            }
            shapeRenderer.end();
        }

        // Отрисовка жизней (сердечек)
        batch.begin();
        batch.setProjectionMatrix(new Matrix4().setToOrtho2D(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight()));
        for (int i = 0; i < lives; i++) {
            float x = Gdx.graphics.getWidth() - 45 * (i + 1);
            float y = Gdx.graphics.getHeight() - 45;
            batch.draw(heartTexture, x, y, 40, 40);
        }

        // Отрисовка активного щита
        if (isShieldActive) {
            batch.draw(activeShieldTexture, 20, Gdx.graphics.getHeight() - 50 - activeShieldTexture.getHeight());
        }

        // Отрисовка активного эффекта пули
        if (isBulletEffectActive) {
            batch.draw(bulletEffectTexture, 20, Gdx.graphics.getHeight() - 50 - activeShieldTexture.getHeight() - 50);
        }

        // Применяем эффект мигания при неуязвимости
        if (isInvincible) {
            float alpha = (MathUtils.sin(invincibleTimer * 20) + 1) / 2 * 0.7f + 0.3f;
            batch.setColor(1, 1, 1, alpha);
        } else {
            batch.setColor(Color.WHITE);
        }

        player.render(batch);
        batch.setColor(Color.WHITE); // Сбрасываем цвет

        batch.end();

        // Отрисовка UI
        stage.act(delta);
        stage.draw();

        checkCollisions();
        checkEnemyBulletCollisions(); // Проверка коллизий вражеских пуль
        checkHeartCollisions(); // Проверка сбора сердечек
        checkShieldCollisions(); // Проверка сбора щитов
        checkExtraBulletCollisions(); // Проверка сбора пуль-бонусов
    }

    private void update(float delta) {
        // Обновление фона

        if (isInvincible) {
            invincibleTimer += delta;
            if (invincibleTimer >= INVINCIBLE_DURATION && !isShieldActive) {
                isInvincible = false;
            }
        }

        // Обновление таймера щита
        if (isShieldActive) {
            shieldTimer -= delta;
            if (shieldTimer <= 0) {
                isShieldActive = false;
                // Снимаем неуязвимость только если не активна неуязвимость от удара
                if (invincibleTimer <= 0) {
                    isInvincible = false;
                }
            }
        }

        // Обновление таймера эффекта пули
        if (isBulletEffectActive) {
            bulletEffectTimer -= delta;
            if (bulletEffectTimer <= 0) {
                isBulletEffectActive = false;
                player.resetFireRate(); // Сбрасываем улучшение стрельбы
            }
        }

        background.update(delta, player.isMoving() ? player.getVelocity() : Vector2.Zero);

        gameTime += delta;

        player.update(delta);
        obstacles.update(delta, gameTime, bullets, player.getCenterPosition());

        // Замените блок стрельбы в методе render()
        if (isTouching && player.canShoot()) {
            Vector2[] gunPositions = player.getGunPositions();
            float rotation = player.getRotation();

            // Изменение направления стрельбы на влево (+90° к текущему повороту)
            float leftAngle = rotation + 90;

            // Скорость пуль: если активен эффект, то увеличиваем
            float bulletSpeed = player.getBulletSpeed();

            for (Vector2 gunPosition : gunPositions) {
                bullets.add(new Bullet(gunPosition.x, gunPosition.y, leftAngle, true, bulletSpeed));
            }

            player.shoot();
        }

        // Обновление пуль
        Iterator<Bullet> bulletIter = bullets.iterator();
        while (bulletIter.hasNext()) {
            Bullet bullet = bulletIter.next();
            bullet.update(delta);

            // Удаление вышедших за пределы экрана
            if (!bullet.isActive()) {
                bulletIter.remove();
            }
        }

        // Обновление взрывов
        Iterator<Explosion> explosionIter = explosions.iterator();
        while (explosionIter.hasNext()) {
            Explosion explosion = explosionIter.next();
            explosion.update(delta);
            if (explosion.isFinished()) {
                explosionIter.remove();
            }
        }

        // Обновление сердечек
        Iterator<Heart> heartIter = hearts.iterator();
        while (heartIter.hasNext()) {
            Heart heart = heartIter.next();
            heart.update(delta);

            // Удаление вышедших за пределы экрана
            if (heart.getY() < -heart.getHeight()) {
                heartIter.remove();
            }
        }

        // Обновление щитов
        Iterator<Shield> shieldIter = shields.iterator();
        while (shieldIter.hasNext()) {
            Shield shield = shieldIter.next();
            shield.update(delta);

            // Удаление вышедших за пределы экрана
            if (shield.getY() < -shield.getHeight()) {
                shieldIter.remove();
            }
        }

        // Обновление пуль-бонусов
        Iterator<ExtraBullet> extraBulletIter = extraBullets.iterator();
        while (extraBulletIter.hasNext()) {
            ExtraBullet bullet = extraBulletIter.next();
            bullet.update(delta);

            // Удаление вышедших за пределы экрана
            if (bullet.getY() < -bullet.getHeight()) {
                extraBulletIter.remove();
            }
        }

        // Проверка коллизий пуль с препятствиями
        checkBulletCollisions();

        float spawnInterval = MathUtils.lerp(2.0f, 0.5f, Math.min(gameTime / 60, 1));

        if (gameTime % spawnInterval < delta) {
            if (!obstacleSpawned) {
                obstacles.spawnObstacle();
                obstacleSpawned = true;
            }
        } else {
            obstacleSpawned = false;
        }

        score = (int) gameTime;
        scoreLabel.setText("Score: " + score);
    }

    private void checkHeartCollisions() {
        Iterator<Heart> heartIter = hearts.iterator();
        while (heartIter.hasNext()) {
            Heart heart = heartIter.next();
            if (player.getBounds().overlaps(heart.getBounds())) {
                heartIter.remove();
                lives = Math.min(lives + 1, 5); // Максимум 5 жизней
            }
        }
    }

    private void checkShieldCollisions() {
        Iterator<Shield> shieldIter = shields.iterator();
        while (shieldIter.hasNext()) {
            Shield shield = shieldIter.next();
            if (player.getBounds().overlaps(shield.getBounds())) {
                shieldIter.remove();
                activateShield();
            }
        }
    }

    private void checkExtraBulletCollisions() {
        Iterator<ExtraBullet> iter = extraBullets.iterator();
        while (iter.hasNext()) {
            ExtraBullet bullet = iter.next();
            if (player.getBounds().overlaps(bullet.getBounds())) {
                iter.remove();
                activateBulletEffect();
            }
        }
    }

    private void activateShield() {
        isShieldActive = true;
        shieldTimer = SHIELD_DURATION;
        isInvincible = true;
    }

    private void activateBulletEffect() {
        isBulletEffectActive = true;
        bulletEffectTimer = BULLET_EFFECT_DURATION;
        player.increaseFireRate();
    }

    private void checkEnemyBulletCollisions() {
        if (isInvincible) return;

        Iterator<Bullet> iter = bullets.iterator();
        while (iter.hasNext()) {
            Bullet bullet = iter.next();
            if (!bullet.isPlayerBullet() && player.getBounds().overlaps(bullet.getBounds())) {
                // Удаляем пулю при попадании в игрока
                iter.remove();
                handlePlayerHit();
                return; // Прерываем после первого попадания
            }
        }
    }

    private void handlePlayerHit() {
        // Если активен щит - поглощаем удар
        if (isShieldActive) {
            isShieldActive = false;
            isInvincible = true;
            invincibleTimer = INVINCIBLE_DURATION;
            return;
        }

        lives--;
        isInvincible = true;
        invincibleTimer = 0;

        if (lives <= 0) {
            game.setScreen(new EndScreen(game, score));
        }
    }

    private void checkCollisions() {
        if (isInvincible) return;

        // Используем итератор для безопасного удаления
        Iterator<Obstacle> iterator = obstacles.getObstacles().iterator();
        while (iterator.hasNext()) {
            Obstacle obstacle = iterator.next();
            if (player.getBounds().overlaps(obstacle.getBounds())) {
                // Создаем взрыв на месте врага
                explosions.add(new Explosion(
                    explosionTexture,
                    obstacle.getX() + obstacle.getWidth() / 2f,
                    obstacle.getY() + obstacle.getHeight() / 2f
                ));

                // Удаляем врага
                iterator.remove();
                obstacles.obstaclePool.free(obstacle);

                // Обрабатываем попадание по игроку
                handlePlayerHit();
                return; // Прерываем после первого столкновения
            }
        }
    }

    private void checkBulletCollisions() {
        Iterator<Bullet> bulletIter = bullets.iterator();
        while (bulletIter.hasNext()) {
            Bullet bullet = bulletIter.next();
            // Пропускаем вражеские пули
            if (!bullet.isPlayerBullet()) continue;
            Iterator<Obstacle> obstacleIter = obstacles.getObstacles().iterator();
            while (obstacleIter.hasNext()) {
                Obstacle obstacle = obstacleIter.next();
                if (bullet.getBounds().overlaps(obstacle.getBounds())) {
                    bullet.setActive(false);

                    // Создаем взрыв в позиции врага
                    explosions.add(new Explosion(
                        explosionTexture,
                        obstacle.getX() + obstacle.getWidth() / 2f,
                        obstacle.getY() + obstacle.getHeight() / 2f
                    ));

                    // С шансом 3% создаем сердечко
                    if (MathUtils.random(100) < 15) {
                        hearts.add(new Heart(
                            extraHeartTexture,
                            obstacle.getX() + obstacle.getWidth() / 2f,
                            obstacle.getY() + obstacle.getHeight() / 2f
                        ));
                    }

                    // С шансом 15% создаем щит
                    if (MathUtils.random(100) < 15) {
                        shields.add(new Shield(
                            extraShieldTexture,
                            obstacle.getX() + obstacle.getWidth() / 2f,
                            obstacle.getY() + obstacle.getHeight() / 2f
                        ));
                    }

                    // С шансом 15% создаем пулю-бонус
                    if (MathUtils.random(100) < 15) {
                        extraBullets.add(new ExtraBullet(
                            extraBulletTexture,
                            obstacle.getX() + obstacle.getWidth() / 2f,
                            obstacle.getY() + obstacle.getHeight() / 2f
                        ));
                    }

                    obstacleIter.remove();
                    obstacles.obstaclePool.free(obstacle);
                    break;
                }
            }
        }
    }


    @Override
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height);
        stage.getViewport().update(width, height, true);
        if (background != null) {
            background.resize(width, height);
        }
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        batch.dispose();
        playerTexture.dispose();
        for (Texture texture : obstacleTextures) {
            texture.dispose();
        }
        explosionTexture.dispose(); // Освобождаем ресурсы взрыва
        extraHeartTexture.dispose(); // Освобождаем ресурсы сердечка
        extraShieldTexture.dispose(); // Освобождаем ресурсы щита
        activeShieldTexture.dispose(); // Освобождаем ресурсы активного щита
        extraBulletTexture.dispose(); // Освобождаем ресурсы пули-бонуса
        bulletEffectTexture.dispose(); // Освобождаем ресурсы иконки эффекта
        stage.dispose();
        background.dispose();
        heartTexture.dispose();
    }

    // Класс сердечка-бонуса
    private static class Heart {
        private final Texture texture;
        private final Vector2 position;
        private final Rectangle bounds;
        private final float speed;

        public Heart(Texture texture, float centerX, float centerY) {
            this.texture = texture;
            this.position = new Vector2(
                centerX - texture.getWidth() / 2f,
                centerY - texture.getHeight() / 2f
            );
            this.bounds = new Rectangle(
                position.x, position.y,
                texture.getWidth(), texture.getHeight()
            );
            this.speed = 150f; // Скорость падения
        }

        public void update(float delta) {
            position.y -= speed * delta;
            bounds.setPosition(position.x, position.y);
        }

        public void render(SpriteBatch batch) {
            batch.draw(texture, position.x, position.y);
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public float getY() {
            return position.y;
        }

        public float getHeight() {
            return texture.getHeight();
        }
    }

    // Класс щита-бонуса
    private static class Shield {
        private final Texture texture;
        private final Vector2 position;
        private final Rectangle bounds;
        private final float speed;

        public Shield(Texture texture, float centerX, float centerY) {
            this.texture = texture;
            this.position = new Vector2(
                centerX - texture.getWidth() / 2f,
                centerY - texture.getHeight() / 2f
            );
            this.bounds = new Rectangle(
                position.x, position.y,
                texture.getWidth(), texture.getHeight()
            );
            this.speed = 150f; // Скорость падения
        }

        public void update(float delta) {
            position.y -= speed * delta;
            bounds.setPosition(position.x, position.y);
        }

        public void render(SpriteBatch batch) {
            batch.draw(texture, position.x, position.y);
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public float getY() {
            return position.y;
        }

        public float getHeight() {
            return texture.getHeight();
        }
    }

    // Класс пули-бонуса
    private static class ExtraBullet {
        private final Texture texture;
        private final Vector2 position;
        private final Rectangle bounds;
        private final float speed;

        public ExtraBullet(Texture texture, float centerX, float centerY) {
            this.texture = texture;
            this.position = new Vector2(
                centerX - texture.getWidth() / 2f,
                centerY - texture.getHeight() / 2f
            );
            this.bounds = new Rectangle(
                position.x, position.y,
                texture.getWidth(), texture.getHeight()
            );
            this.speed = 150f; // Скорость падения
        }

        public void update(float delta) {
            position.y -= speed * delta;
            bounds.setPosition(position.x, position.y);
        }

        public void render(SpriteBatch batch) {
            batch.draw(texture, position.x, position.y);
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public float getY() {
            return position.y;
        }

        public float getHeight() {
            return texture.getHeight();
        }
    }

    // Класс взрыва
    private static class Explosion {
        private final Texture texture;
        private final Vector2 position;
        private final float duration = 0.5f; // Длительность анимации
        private float timer;

        public Explosion(Texture texture, float centerX, float centerY) {
            this.texture = texture;
            this.position = new Vector2(
                centerX - texture.getWidth() / 2f,
                centerY - texture.getHeight() / 2f
            );
            this.timer = duration;
        }

        public void update(float delta) {
            timer -= delta;
        }

        public void render(SpriteBatch batch) {
            if (timer <= 0) return;

            // Прозрачность уменьшается со временем
            float alpha = timer / duration;
            Color originalColor = batch.getColor();
            batch.setColor(1, 1, 1, alpha);
            batch.draw(texture, position.x, position.y);
            batch.setColor(originalColor);
        }

        public boolean isFinished() {
            return timer <= 0;
        }
    }

    // Класс пули
    private static class Bullet {
        private final Vector2 position;
        private final Vector2 velocity;
        private final Rectangle bounds;
        private boolean active;

        private final boolean isPlayerBullet; // Определяет тип пули


        public Bullet(float startX, float startY, float angleDeg, boolean isPlayerBullet, float speed) {
            position = new Vector2(startX, startY);
            bounds = new Rectangle(startX - 2, startY - 4, 4, 8);
            active = true;
            this.isPlayerBullet = isPlayerBullet;

            // Правильный расчет направления без дополнительных поправок
            float angleRad = angleDeg * MathUtils.degreesToRadians;

            velocity = new Vector2(
                MathUtils.cos(angleRad) * speed,
                MathUtils.sin(angleRad) * speed
            );
        }

        public void update(float delta) {
            if (!active) return;

            position.x += velocity.x * delta;
            position.y += velocity.y * delta;
            bounds.setPosition(position.x - 2, position.y - 4);

            // Деактивация за пределами экрана
            if (position.x < -10 || position.x > Gdx.graphics.getWidth() + 10 ||
                position.y < -10 || position.y > Gdx.graphics.getHeight() + 10) {
                active = false;
            }
        }

        public void render(ShapeRenderer shapeRenderer) {
            if (!active) return;
            shapeRenderer.rect(bounds.x, bounds.y, bounds.width, bounds.height);
        }

        public boolean isActive() {
            return active;
        }

        public boolean isPlayerBullet() {
            return isPlayerBullet;
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public void setActive(boolean active) {
            this.active = active;
        }
    }

    private static class Player {
        private final Texture texture;
        private final Vector2 position;
        private final Rectangle bounds;
        private final Vector2 velocity = new Vector2();
        private float rotation;

        // Параметры движения
        private static final float MAX_SPEED = 350f;
        private static final float ACCELERATION = 800f;
        private static final float DECELERATION = 1200f;
        private static final float BRAKING_RADIUS = 100f;
        private static final float MIN_DISTANCE = 5f;
        private static final float MOVEMENT_THRESHOLD = 5f; // Порог движения в пикселях/сек

        // Параметры стрельбы
        private boolean isMoving;
        private float shotCooldown;
        private static final float SHOT_COOLDOWN = 0.3f; // * выстрелов/сек

        // Эффект улучшения стрельбы
        private float fireRateMultiplier = 1.0f;
        private float bulletSpeedMultiplier = 1.0f;
        private int bulletCount = 2; // Обычно две пушки

        // Целевая позиция
        private Vector2 targetPosition = new Vector2();

        public Player(Texture texture, float startX, float startY) {
            this.texture = texture;
            this.position = new Vector2(startX, startY);
            this.bounds = new Rectangle();
            this.bounds.setSize(texture.getWidth(), texture.getHeight());
            setTargetPosition(
                startX + texture.getWidth() / 2f,
                startY + texture.getHeight() / 2f
            );
        }

        public void setPosition(float x, float y) {
            position.set(x, y);
            bounds.setPosition(x, y);
        }

        public void setTargetPosition(float x, float y) {
            targetPosition.set(x, y);
        }

        public void update(float delta) {
            // Обновление кулдауна стрельбы
            shotCooldown -= delta;

            // Расчет центра спрайта
            float centerX = position.x + texture.getWidth() / 2f;
            float centerY = position.y + texture.getHeight() / 2f;

            // Вектор к цели
            Vector2 toTarget = new Vector2(
                targetPosition.x - centerX,
                targetPosition.y - centerY
            );
            float distance = toTarget.len();

            // Управление скоростью
            if (distance > MIN_DISTANCE) {
                toTarget.nor();

                float targetSpeed = MAX_SPEED;
                if (distance < BRAKING_RADIUS) {
                    targetSpeed *= (distance / BRAKING_RADIUS);
                }

                Vector2 desiredVelocity = new Vector2(toTarget).scl(targetSpeed);
                Vector2 steering = new Vector2(desiredVelocity).sub(velocity);

                float acceleration = (velocity.dot(toTarget) > 0) ? ACCELERATION : DECELERATION;
                steering.limit(acceleration * delta);

                velocity.add(steering);

                if (velocity.len() > MAX_SPEED) {
                    velocity.nor().scl(MAX_SPEED);
                }
            } else {
                velocity.scl(0.2f * delta);
                if (velocity.len() < 5f) velocity.set(0, 0);
            }

            // Обновление позиции
            position.x += velocity.x * delta;
            position.y += velocity.y * delta;

            // Ограничение в пределах экрана
            position.x = MathUtils.clamp(position.x, 0, Gdx.graphics.getWidth() - texture.getWidth());
            position.y = MathUtils.clamp(position.y, 0, Gdx.graphics.getHeight() - texture.getHeight());

            // Обновление границ
            bounds.setPosition(position);

            // Определение движения
            isMoving = velocity.len() > MOVEMENT_THRESHOLD;

            // Обновление поворота
            if (!velocity.isZero()) {
                rotation = velocity.angleDeg() - 90;
            }
        }

        public void render(SpriteBatch batch) {
            // Сохраняем оригинальный цвет
            Color originalColor = batch.getColor();

            // Если нужно применить эффект (например, при неуязвимости)
            // Эффект будет управляться из GameScreen, поэтому здесь не нужно изменять

            // Отрисовка игрока
            float originX = texture.getWidth() / 2f;
            float originY = texture.getHeight() / 2f;

            batch.draw(
                texture,
                position.x,
                position.y,
                originX,
                originY,
                texture.getWidth(),
                texture.getHeight(),
                1,
                1,
                rotation,
                0,
                0,
                texture.getWidth(),
                texture.getHeight(),
                false,
                false
            );

            // Восстанавливаем оригинальный цвет
            batch.setColor(originalColor);
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public Vector2 getVelocity() {
            return velocity;
        }

        public void renderDebug(ShapeRenderer shapeRenderer) {
            Vector2[] gunPositions = getGunPositions();

            shapeRenderer.setColor(Color.RED);
            shapeRenderer.circle(gunPositions[0].x, gunPositions[0].y, 5); // Левое орудие
            shapeRenderer.circle(gunPositions[1].x, gunPositions[1].y, 5); // Правое орудие

            // Линия направления корабля
            float directionX = MathUtils.cosDeg(rotation) * 50;
            float directionY = MathUtils.sinDeg(rotation) * 50;
            float centerX = position.x + texture.getWidth() / 2f;
            float centerY = position.y + texture.getHeight() / 2f;
            shapeRenderer.setColor(Color.GREEN);
            shapeRenderer.line(centerX, centerY, centerX + directionX, centerY + directionY);

            // Линии для перпендикулярных векторов
            shapeRenderer.setColor(Color.BLUE);
            float perpendicularX = -directionY * 30;
            float perpendicularY = directionX * 30;
            shapeRenderer.line(centerX, centerY, centerX + perpendicularX, centerY + perpendicularY);
            shapeRenderer.line(centerX, centerY, centerX - perpendicularX, centerY - perpendicularY);
        }

        // Методы для стрельбы
        public Vector2[] getGunPositions() {
            float centerX = position.x + texture.getWidth() / 2f;
            float centerY = position.y + texture.getHeight() / 2f;

            // Рассчитываем вектор направления движения
            float directionX = MathUtils.cosDeg(rotation);
            float directionY = MathUtils.sinDeg(rotation);

            // Перпендикулярный вектор (90 градусов к направлению движения)
            float perpendicularX = -directionY;
            float perpendicularY = directionX;

            // Смещение для боковых орудий
            float sideOffset = 30f; // Увеличим смещение для лучшей видимости

            // Если активно улучшение, то добавляем еще две пушки ближе к центру
            if (fireRateMultiplier > 1.0f) {
                return new Vector2[] {
                    // Левое орудие
                    new Vector2(centerX + perpendicularX * sideOffset, centerY + perpendicularY * sideOffset),
                    // Правое орудие
                    new Vector2(centerX - perpendicularX * sideOffset, centerY - perpendicularY * sideOffset),
                    // Левое внутреннее орудие
                    new Vector2(centerX + perpendicularX * (sideOffset - 15), centerY + perpendicularY * (sideOffset - 15)),
                    // Правое внутреннее орудие
                    new Vector2(centerX - perpendicularX * (sideOffset - 15), centerY - perpendicularY * (sideOffset - 15))
                };
            } else {
                return new Vector2[] {
                    // Левое орудие
                    new Vector2(centerX + perpendicularX * sideOffset, centerY + perpendicularY * sideOffset),
                    // Правое орудие
                    new Vector2(centerX - perpendicularX * sideOffset, centerY - perpendicularY * sideOffset)
                };
            }
        }

        public boolean isMoving() {
            return isMoving;
        }

        public boolean canShoot() {
            return shotCooldown <= 0;
        }

        public void shoot() {
            shotCooldown = SHOT_COOLDOWN / fireRateMultiplier;
        }

        public float getRotation() {
            return rotation;
        }

        public Vector2 getCenterPosition() {
            return new Vector2(
                position.x + texture.getWidth() / 2f,
                position.y + texture.getHeight() / 2f
            );
        }

        public void increaseFireRate() {
            fireRateMultiplier = 1.5f; // Увеличиваем скорострельность на 50%
            bulletSpeedMultiplier = 1.5f; // Увеличиваем скорость пуль на 50%
            bulletCount = 4; // Теперь 4 пули
        }

        public void resetFireRate() {
            fireRateMultiplier = 1.0f;
            bulletSpeedMultiplier = 1.0f;
            bulletCount = 2;
        }

        public float getBulletSpeed() {
            return 800f * bulletSpeedMultiplier; // Базовая скорость 800, умножаем на множитель
        }
    }

    private static class ObstacleManager {
        private final Array<Obstacle> activeObstacles;
        private final Pool<Obstacle> obstaclePool;
        private final Texture[] obstacleTextures;
        private float globalSpeedMultiplier = 1.0f;

        private final Array<Bullet> enemyBullets;


        public ObstacleManager(Texture[] textures) {
            this.activeObstacles = new Array<>();
            this.obstacleTextures = textures;

            this.enemyBullets = new Array<>();

            this.obstaclePool = new Pool<Obstacle>() {
                @Override
                protected Obstacle newObject() {
                    int type = MathUtils.random(obstacleTextures.length - 1);
                    Obstacle obstacle = new Obstacle(obstacleTextures[type], type);
                    obstacle.setColor(generateVariantColor(type));
                    return obstacle;
                }
            };
        }

        public void spawnObstacle() {
            Obstacle obstacle = obstaclePool.obtain();
            int side = MathUtils.random(0, 3); // 0=верх, 1=низ, 2=лево, 3=право
            float x, y;

            switch (side) {
                case 0: // верх
                    x = MathUtils.random(0, Gdx.graphics.getWidth() - obstacle.getWidth());
                    y = Gdx.graphics.getHeight();
                    break;
                case 1: // низ
                    x = MathUtils.random(0, Gdx.graphics.getWidth() - obstacle.getWidth());
                    y = -obstacle.getHeight();
                    break;
                case 2: // лево
                    x = -obstacle.getWidth();
                    y = MathUtils.random(0, Gdx.graphics.getHeight() - obstacle.getHeight());
                    break;
                case 3: // право
                    x = Gdx.graphics.getWidth();
                    y = MathUtils.random(0, Gdx.graphics.getHeight() - obstacle.getHeight());
                    break;
                default:
                    x = 0;
                    y = Gdx.graphics.getHeight();
            }

            int directionType = getDirectionForSide(side);
            obstacle.setDirection(directionType);
            obstacle.setColor(generateVariantColor(obstacle.getType()));
            obstacle.setPosition(x, y);
            activeObstacles.add(obstacle);
        }

        private int getDirectionForSide(int side) {
            switch (side) {
                case 0: // сверху - летят вниз
                    return Obstacle.DIR_DOWN;
                case 1: // снизу - летят вверх
                    return Obstacle.DIR_UP;
                case 2: // слева - летят вправо
                    return Obstacle.DIR_RIGHT;
                case 3: // справа - летят влево
                    return Obstacle.DIR_LEFT;
                default:
                    return Obstacle.DIR_DOWN;
            }
        }

        public void update(float delta, float gameTime, Array<Bullet> allBullets, Vector2 playerPosition) {
            globalSpeedMultiplier = 1.0f + gameTime / 30f;

            for (Obstacle obstacle : activeObstacles) {
                obstacle.setSpeedMultiplier(globalSpeedMultiplier);
                obstacle.update(delta, enemyBullets, playerPosition); // Передаем позицию игрока
            }

            allBullets.addAll(enemyBullets);
            enemyBullets.clear();
        }


        public void render(SpriteBatch batch) {
            for (Obstacle obstacle : activeObstacles) {
                obstacle.render(batch);
            }
        }

        public Array<Obstacle> getObstacles() {
            return activeObstacles;
        }

        private Color generateVariantColor(int type) {
            Color[] baseColors = {
                new Color(1, 0.2f, 0.2f, 1),
                new Color(0.2f, 0.8f, 1, 1),
                new Color(0.4f, 1, 0.4f, 1),
                new Color(1, 0.8f, 0.2f, 1),
                new Color(1, 0.5f, 0.8f, 1),
                new Color(0.7f, 0.3f, 1, 1)
            };

            Color baseColor = baseColors[type % baseColors.length];
            float r = MathUtils.clamp(baseColor.r + MathUtils.random(-0.15f, 0.15f), 0, 1);
            float g = MathUtils.clamp(baseColor.g + MathUtils.random(-0.15f, 0.15f), 0, 1);
            float b = MathUtils.clamp(baseColor.b + MathUtils.random(-0.15f, 0.15f), 0, 1);
            return new Color(r, g, b, 1);
        }
    }

    private static class Obstacle {
        private final Texture texture;
        private final Vector2 position;
        private final Rectangle bounds;
        private final float baseSpeed;
        private float currentSpeed;
        private int moveDirection;
        private Vector2 velocity = new Vector2();
        private Color color = Color.WHITE;
        private final int type;
        private float spawnTime = 0;
        private final float sizeScale;

        private static final float[] SPEEDS = {200f, 250f, 300f, 220f};
        private static final int DIR_DOWN_LEFT = 1;
        private static final int DIR_DOWN_RIGHT = 2;
        private static final int DIR_DIAGONAL_LEFT = 3;
        private static final int DIR_DIAGONAL_RIGHT = 4;

        private float shotCooldown;
        private static final float SHOT_INTERVAL = 0.8f; // Интервал между выстрелами
        private final float bulletSpeed;

        // Добавляем новые направления
        private static final int DIR_UP = 5;
        private static final int DIR_DOWN = 0;
        private static final int DIR_LEFT = 6;
        private static final int DIR_RIGHT = 7;

        public Obstacle(Texture texture, int type) {
            this.texture = texture;
            this.type = type;
            this.position = new Vector2();
            this.bounds = new Rectangle();
            this.bounds.setSize(texture.getWidth(), texture.getHeight());
            this.baseSpeed = SPEEDS[type % SPEEDS.length];
            this.currentSpeed = baseSpeed;
            this.moveDirection = DIR_DOWN;
            this.sizeScale = 0.8f + MathUtils.random(0.4f);
            this.shotCooldown = MathUtils.random(0.5f, SHOT_INTERVAL);
            this.bulletSpeed = baseSpeed * 1.8f; // Скорость пуль
            updateVelocity();
        }

        public int getType() {
            return type;
        }

        public void setColor(Color color) {
            this.color = color;
        }

        public void setPosition(float x, float y) {
            position.set(x, y);
            bounds.setPosition(x, y);
            spawnTime = 0;
        }

        public void setDirection(int directionType) {
            this.moveDirection = directionType;
            updateVelocity();
        }

        public void setSpeedMultiplier(float multiplier) {
            currentSpeed = baseSpeed * multiplier;
            updateVelocity();
        }

        private void updateVelocity() {
            switch (moveDirection) {
                case DIR_DOWN:
                    velocity.set(0, -currentSpeed);
                    break;
                case DIR_DOWN_LEFT:
                    velocity.set(-currentSpeed * 0.7f, -currentSpeed);
                    break;
                case DIR_DOWN_RIGHT:
                    velocity.set(currentSpeed * 0.7f, -currentSpeed);
                    break;
                case DIR_DIAGONAL_LEFT:
                    velocity.set(-currentSpeed * 0.9f, -currentSpeed * 0.5f);
                    break;
                case DIR_DIAGONAL_RIGHT:
                    velocity.set(currentSpeed * 0.9f, -currentSpeed * 0.5f);
                    break;
                case DIR_UP:
                    velocity.set(0, currentSpeed);
                    break;
                case DIR_LEFT:
                    velocity.set(-currentSpeed, 0);
                    break;
                case DIR_RIGHT:
                    velocity.set(currentSpeed, 0);
                    break;
                default:
                    velocity.set(0, -currentSpeed);
            }
        }

        public void update(float delta, Array<Bullet> enemyBullets, Vector2 playerPosition) {
            if (spawnTime < 1f) {
                spawnTime += delta * 3f;
            }
            position.x += velocity.x * delta;
            position.y += velocity.y * delta;
            bounds.setPosition(position);
            // Логика стрельбы
            shotCooldown -= delta;
            if (shotCooldown <= 0) {
                shoot(enemyBullets, playerPosition);
                shotCooldown = SHOT_INTERVAL * MathUtils.random(0.7f, 1.3f); // Случайный интервал
            }
        }

        private void shoot(Array<Bullet> enemyBullets, Vector2 playerPosition) {
            float centerX = position.x + getWidth() / 2f;
            float centerY = position.y + getHeight() / 2f;

            // Рассчитываем направление к игроку
            Vector2 direction = new Vector2(
                playerPosition.x - centerX,
                playerPosition.y - centerY
            ).nor();

            // Угол в градусах
            float angle = direction.angleDeg();

            // Добавляем случайный разброс
            angle += MathUtils.random(-15f, 15f);

            enemyBullets.add(new Bullet(centerX, centerY, angle, false, bulletSpeed));
        }

        public void render(SpriteBatch batch) {
            Color original = batch.getColor();
            Color renderColor = new Color(color);
            if (spawnTime < 1f) {
                renderColor.a *= spawnTime;
            }
            batch.setColor(renderColor);

            float rotation = velocity.angleDeg() + 90;
            float width = texture.getWidth() * sizeScale;
            float height = texture.getHeight() * sizeScale;

            batch.draw(
                texture,
                position.x,
                position.y,
                width / 2f,
                height / 2f,
                width,
                height,
                1,
                1,
                rotation,
                0,
                0,
                texture.getWidth(),
                texture.getHeight(),
                false,
                false
            );
            batch.setColor(original);
        }

        public Rectangle getBounds() {
            return bounds;
        }

        public float getX() {
            return position.x;
        }

        public float getY() {
            return position.y;
        }

        public float getWidth() {
            return texture.getWidth() * sizeScale;
        }

        public float getHeight() {
            return texture.getHeight() * sizeScale;
        }
    }
}
